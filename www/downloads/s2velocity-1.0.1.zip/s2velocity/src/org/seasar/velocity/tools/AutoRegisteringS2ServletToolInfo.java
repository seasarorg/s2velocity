package org.seasar.velocity.tools;

import org.apache.velocity.app.Velocity;
import org.seasar.framework.container.ComponentDef;
import org.seasar.framework.container.ContainerConstants;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;
import org.seasar.framework.container.impl.ComponentDefImpl;

/**
 * DICONファイルにコンポーネント登録しなくても、toolbox.xmlから
 * 自動的に登録を行なうToolInfoクラス。
 * 
 * @author <a href="mailto:sato@ouobpo.org">Sato Tadayosi</a>
 * 
 * @version $Id: AutoRegisteringS2ServletToolInfo.java,v 1.4 2004/11/27 07:06:00 sato Exp $
 */
public class AutoRegisteringS2ServletToolInfo extends S2ServletToolInfo {

  protected static final String COMPONENT_NAME_PREFIX = "velocity.toolbox.";

  /**
   * Overrides {@link S2ServletToolInfo}.
   * ツールのインスタンスは、すべてコンテナに管理させる。
   * また、親メソッドと違い、コンポーネント名を元にコンポーネントを取得する。
   * こうすることで、コンポーネント衝突を回避できる。
   */
  protected Object createToolInstance() {
    Object tool = null;

    S2Container container = SingletonS2ContainerFactory.getContainer();
    String compName = COMPONENT_NAME_PREFIX + getKey();
    try {
      if (!container.hasComponentDef(compName)) {
        // NOTE ツールのコンテナへの登録。toolbox.xmlのスコープを有効にするため、ツールはすべてprototypeとして管理される。
        ComponentDef compDef = new ComponentDefImpl(clazz, compName);

        /*
         * Velocity View がスコープ毎に適切にgetInstanceメソッドを呼び出しているので、
         * S2側では、すべてprototypeにしてしまってよいはず。
         * TODO request, sessionのインスタンス管理を指定したら上手くいかなかった。要調査。
         */
        compDef.setInstanceMode(ContainerConstants.INSTANCE_PROTOTYPE);

        container.register(compDef);
      }
      tool = container.getComponent(compName);
    } catch (Exception e) {
      // コンテナへの登録に失敗した場合
      Velocity.error(e);
    }

    return tool;
  }
}