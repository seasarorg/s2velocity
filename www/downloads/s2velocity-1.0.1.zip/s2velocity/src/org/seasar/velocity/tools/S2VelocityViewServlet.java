/*
 * Copyright 2003 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.seasar.velocity.tools;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.velocity.app.Velocity;
import org.apache.velocity.tools.view.servlet.VelocityViewServlet;

/**
 * @author <a href="mailto:sato@ouobpo.org">Sato Tadayosi</a>
 * 
 * @version $Id: S2VelocityViewServlet.java,v 1.3 2004/11/26 18:22:42 sato Exp $
 */
public class S2VelocityViewServlet extends VelocityViewServlet {

  /**
   * Overrides {@link S2VelocityViewServlet} to change toolboxManager
   * implementation from ServletToolboxManager to S2ServletToolboxManager.
   * 
   * Initializes the S2ServletToolboxManager for this servlet's
   * toolbox (if any).
   *
   * @param config servlet configuration
   */
  protected void initToolbox(ServletConfig config) throws ServletException {
    ServletContext servletContext = config.getServletContext();

    /* check the servlet config for a toolbox */
    String file = config.getInitParameter(TOOLBOX_KEY);

    /* check the servlet context for a toolbox */
    if (file == null || file.length() == 0) {
      file = servletContext.getInitParameter(TOOLBOX_KEY);
    }

    /* if we have a toolbox, get a manager for it */
    if (file != null) {
      toolboxManager = S2ServletToolboxManager
          .getInstance(servletContext, file); // changed here.
    } else {
      Velocity.info("VelocityViewServlet: No toolbox entry in configuration.");
    }
  }

}