package org.seasar.velocity.tools;

import org.apache.velocity.tools.view.servlet.ServletToolboxRuleSet;

/**
 * @author <a href="mailto:sato@ouobpo.org">Sato Tadayosi</a>
 * 
 * @version $Id: S2ServletToolboxRuleSet.java,v 1.3 2004/11/26 18:22:42 sato Exp $
 */
public class S2ServletToolboxRuleSet extends ServletToolboxRuleSet {

  /**
   * Overrides {@link ServletToolboxRuleSet} to use S2ServletToolInfo class.
   */
  protected Class getToolInfoClass() {
    // NOTE to turn off auto-registration from toolbox.xml, just change here.
    //return S2ServletToolInfo.class;
    return AutoRegisteringS2ServletToolInfo.class;
  }
}