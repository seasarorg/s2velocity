ソースコードのコンパイルに必要なjarファイルは以下の通りです。

commons-digester.jar
s2-framework-x.x.x.jar
velocity-dep-x.x.x.jar
velocity-tools-x.x.jar

それぞれ、以下のサイトより取得してください。

http://www.seasar.org/
http://jakarta.apache.org/velocity/tools/