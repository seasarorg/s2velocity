package org.seasar.velocity.tools.examples.hello;

public class HelloImpl implements IHello {

  public String getHello() {
    return "こんにちは";
  }
}