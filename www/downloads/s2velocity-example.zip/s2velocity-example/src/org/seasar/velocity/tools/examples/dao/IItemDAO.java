package org.seasar.velocity.tools.examples.dao;

public interface IItemDAO {

  public String[] findAllItems();
}