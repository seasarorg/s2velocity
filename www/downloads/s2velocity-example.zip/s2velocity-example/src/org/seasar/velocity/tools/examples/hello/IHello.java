package org.seasar.velocity.tools.examples.hello;

public interface IHello {

  public String getHello();
}