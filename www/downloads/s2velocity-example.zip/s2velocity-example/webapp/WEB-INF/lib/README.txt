サンプル実行に必要なjarファイルは以下の通りです。

aopalliance.jar
cglib-x.x.jar
commons-beanutils.jar
commons-collections.jar
commons-digester.jar
commons-logging.jar
ognl-x.x.x.jar
s2-framework-x.x.x.jar
s2velocity-x.x.x.jar
velocity-dep-x.x.x.jar
velocity-tools-x.x.jar

それぞれ、以下のサイトより取得してください。

http://www.seasar.org/
http://jakarta.apache.org/velocity/tools/