ソースコードのコンパイルに必要なjarファイルは以下の通りです。

commons-digester-1.7.jar
commons-logging-1.0.x.jar
s2-framework-2.3.x.jar
velocity-1.4.jar
velocity-tools-1.2.jar

それぞれ、以下のサイトより取得してください。

http://www.seasar.org/
http://jakarta.apache.org/velocity/tools/